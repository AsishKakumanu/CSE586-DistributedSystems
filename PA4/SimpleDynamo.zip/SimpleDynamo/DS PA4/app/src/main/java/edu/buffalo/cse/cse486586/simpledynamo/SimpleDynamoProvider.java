package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

public class SimpleDynamoProvider extends ContentProvider {

    /* TAG for Logging */
    static final String TAG = SimpleDynamoProvider.class.getName();

    /* PORTS */
    static final int SERVER_PORT = 10000;
    static final String[] REMOTE_PORTS = new String[] { "11108", "11112", "11116", "11120", "11124" };

    /* URI Builder */
    String authority = "edu.buffalo.cse.cse486586.simpledynamo.provider";
    String scheme = "content";
    uriBuilder uB = new uriBuilder();
    private final Uri providerUri = uB.buildUri(scheme, authority);

    /* Nodes */
    ArrayList<Node> nodeArrayList = new ArrayList<Node>();
    ArrayList<String> nodeList = new ArrayList<String>();
    ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(100000);
    ConcurrentHashMap<String, String> hMap = new ConcurrentHashMap<String, String>();
    ConcurrentHashMap<String,String> replicatedHMap = new ConcurrentHashMap<String, String>();
    public String masterNode = "5554";

    public String successor = "";
    public String predecessor = "";

    boolean check = false;

    /* Files */
    String nullResult = null;
    ArrayList<String> files = new ArrayList<String>();

    /* Messages */
    String insert = "INSERT";
    String delete = "DELETE";
    String query = "QUERY";
    String delimiter = "#";
    String message_type_JOIN = "NEW_NODE";
    String message_type_update = "UPDATE";

    /* Delete */
    boolean GDUMP = false;
    boolean LDUMP = false;
    boolean individual = false;
    HashMap<String, String> keysToDelete = new HashMap<String, String>();

    /* NODE HASHES */
    private String PORT_5554_HASH;
    private String PORT_5556_HASH;
    private String PORT_5558_HASH;
    private String PORT_5560_HASH;
    private String PORT_5562_HASH;

    {
        try {
            PORT_5554_HASH = genHash(Declarations.PORT_5554);
            PORT_5556_HASH = genHash(Declarations.PORT_5556);
            PORT_5558_HASH = genHash(Declarations.PORT_5558);
            PORT_5560_HASH = genHash(Declarations.PORT_5560);
            PORT_5562_HASH = genHash(Declarations.PORT_5562);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }



    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }



    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub

        String key = values.get("key").toString();
        String value = values.get("value").toString();
        if(!value.contains(":")){
            value = value + ":" +System.currentTimeMillis();
        }

        Log.i(TAG, "Inside INSERT PREDECESSOR:" + predecessor);
        Log.i(TAG, "Inside INSERT SUCCESSOR:" + successor);
        Log.i(TAG, "Booleans in insert : " + GDUMP + "#" + LDUMP + "#" + individual);

        try {
            String hashKey = genHash(key);
            Log.i(TAG, "Inserting / key :" + key +"#" + value);
            Log.i(TAG, "Check Condition " + checkCondition(key));

            /*String[] ports = getOwners(key).split("#");
            if(inAny(ports)==true){

                Log.i(TAG,"Insert method inside if");
                queue.put(key);
                if(hMap.contains(key)){
                    if(getTimeStamp(hMap.get(key)).compareTo(getTimeStamp(value))<0){
                        hMap.put(key,value);
                    }
                }
                else{
                    hMap.put(key,value);
                }

                try {
                    String insertMessage = insert + "#" + key + "#" + value + "#" + successor;
                    for(String port:ports){
                        if(!port.equals(getAvdNumber(getPort()))){
                            sendMessage(port,insertMessage);
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else{

                String insertMessage = insert + "#" + key + "#" + value + "#" + successor;
                for(String port:ports){
                    sendMessage(port,insertMessage);
                }

                Log.i(TAG, "Insert Method inside else, sending message to successor null " + successor.toString() + "#"
                        + insertMessage);
                if (successor != null) {
                    Log.i(TAG, "Insert Method inside else not null, sending message to successor "
                            + successor.toString() + "#" + insertMessage);

                }

            }*/

            if (checkCondition(key) == true) {
                Log.i(TAG, "Insert Method inside if");
                PrintWriter printWriter = new PrintWriter(getContext().openFileOutput(key, Context.MODE_PRIVATE));
                printWriter.println(value);
                printWriter.close();
                queue.put(key);
                if(hMap.containsKey(key)){
                    if(getTimeStamp(hMap.get(key)).compareTo(getTimeStamp(value))<0){
                        hMap.put(key, value);
                    }
                }
                else {
                    hMap.put(key,value);
                }

                Log.i(TAG, "Queue list : " + queue.toString());
                Log.i(TAG, "HMAP List :" + "PORT :" + getPort().toString() + "#" + hMap.toString());

                try {
                    String Repli_message = "REPLI" + "#" + key + "#" + value + "#";
                    Declarations declarations = new Declarations();
                    String[] Nodes = declarations.getReplicaNodes(getAvdNumber(getPort())).split("#");
                    for(int i=0; i<Nodes.length;i++){
                        sendMessage(Nodes[i], Repli_message);
                        Log.i(TAG,"Repli in Insert in port: "+ String.valueOf(Integer.parseInt(Nodes[i]) * 2) + "#" + Repli_message);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                String insertMessage = insert + "#" + key + "#" + value + "#" + successor;
                ClientTask clientTask = new ClientTask();
                clientTask.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, insertMessage,
                        String.valueOf(Integer.parseInt(successor) * 2));
                Log.i(TAG, "Insert Method inside else, sending message to successor null " + successor.toString() + "#"
                        + insertMessage);
                if (successor != null) {
                    Log.i(TAG, "Insert Method inside else not null, sending message to successor "
                            + successor.toString() + "#" + insertMessage);

                }
            }



        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "insert / No Such Algorithm Exception " + e);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "insert / File Not Found Exception " + e);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }



    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        if (selection.contains("*")) {
            GDUMP = true;
            Log.i(TAG, "GDUMP boolean : " + GDUMP);

        } else if (selection.contains("@")) {
            LDUMP = true;
            Log.i(TAG, "LDUMP boolean : " + LDUMP);

        } else {
            individual = true;
            Log.i(TAG, "Individual boolean : " + individual);
            keysToDelete.put(selection, selection);
            Log.i(TAG, "keys to delete are " + keysToDelete.toString());
        }

        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // TODO Auto-generated method stub

        if(check = false){
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        String message = "";

        // A mutable cursor created to add rows.
        String[] keyValuePair = { "key", "value" };

        // Building a row of values using KeyValue Pair
        MatrixCursor myCursor = new MatrixCursor(keyValuePair);

        // Retrieving the dialogs context.
        Context context = getContext();

        String[] listOfFiles = context.fileList();
        Log.i(TAG, "Replicated List  :" + "#" + replicatedHMap.toString());
        Log.i(TAG, "HMAP List after replication insert :" + "#" + hMap.toString());


        try {

            if (selection.contains("@") || selection.contains("*")) {
                Log.i(TAG, "enetered *  with slection " + selection);
                // Opening a private file with context associated with the applications context
                // and reading the bytes into characters.
                if (!successor.equalsIgnoreCase("") && selection.contains("*")) {
                    Socket successorSocket = getSocket(String.valueOf(Integer.parseInt(successor) * 2));
                    PrintWriter printWriter = new PrintWriter(successorSocket.getOutputStream(), true);
                    String message1 = "GDUMP#" + Integer.parseInt(getPort()) / 2;
                    printWriter.println(message1);
                    printWriter.flush();
                    // printWriter.close();

                    InputStreamReader inputStreamReader = new InputStreamReader(successorSocket.getInputStream());
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String AckMessageGDUMP = null;
                    while (true) {
                        AckMessageGDUMP = bufferedReader.readLine();
                        if (AckMessageGDUMP != null) {
                            break;
                        }
                    }
                    Log.i(TAG, " AckMessageGDUMP in query " + AckMessageGDUMP);

                    try {

                        Iterator<String> iter = hMap.keySet().iterator();
                        while (iter.hasNext()) {
                            String key = iter.next();
                            //String value = hMap.get(key).split(":")[0];
                            String value = getValue(hMap.get(key));
                            if (!keysToDelete.containsKey(key)) {
                                myCursor.addRow(new String[] { key, value });
                            }

                        }
                        JSONObject json = new JSONObject(AckMessageGDUMP);

                        Iterator<String> iter1 = json.keys();
                        while (iter1.hasNext()) {
                            String key = iter1.next();
                            //String value = json.getString(key).split(":")[0];
                            String value = getValue(json.getString(key));
                            if (!keysToDelete.containsKey(key)) {
                                myCursor.addRow(new String[] { key, value });
                            }

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else {
                    Iterator<String> iter = hMap.keySet().iterator();
                    while (iter.hasNext()) {
                        String key = iter.next();
                        //String value = hMap.get(key).split(":")[0];
                        String value = getValue(hMap.get(key));
                        if (!keysToDelete.containsKey(key)) {
                            myCursor.addRow(new String[] { key, value });
                        }

                    }
                }

            } else {
                Log.i(TAG, "Inside Query Else Block");
                try {
                    String searchKeyHash = genHash(selection);
                    if (checkCondition(selection)) {
                        /*String name;
                        FileInputStream fileInputStream = context.openFileInput(selection);
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
                        message = bufferedReader.readLine();
                        Log.i(TAG, "Query/ Else Block / Checking Condition / Message : " + message);

                        if (message != null) {
                            String[] record = { selection, message };
                            myCursor.addRow(record);
                        }*/
                        Iterator<String> iter = hMap.keySet().iterator();
                        while (iter.hasNext()) {
                            String key = iter.next();
                            //String value = hMap.get(selection).split(":")[0];
                            String value = getValue(hMap.get(selection));
                            if (!keysToDelete.containsKey(selection)) {
                                myCursor.addRow(new String[] { selection, value });
                            }

                        }
                    } else {
                        String queryMessage = query + "#" + successor + "#KEY_WANTED#" + selection + "#"
                                + getPort().toString();
                        // ClientTask clientTask = new ClientTask();
                        // clientTask.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,queryMessage,String.valueOf(Integer.parseInt(getAvdNumber(getPort()))*2));

                        String[] queryArgs = message.split("#");
                        String successorNode = String.valueOf(Integer.parseInt(successor) * 2);
                        Socket successorSock = getSocket(successorNode);
                        Log.i(TAG, "Query message sent" + queryMessage);
                        PrintWriter printWriter = new PrintWriter(successorSock.getOutputStream(), true);
                        printWriter.println(queryMessage);
                        printWriter.flush();

                        InputStreamReader inputStreamReader = new InputStreamReader(successorSock.getInputStream());
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        String AckMessage = bufferedReader.readLine();
                        Log.i(TAG, "AckMessage inside Query " + AckMessage);

                        String AckMessageArgs[] = AckMessage.split("#");
                        String key = AckMessageArgs[1];
                        //String value = AckMessageArgs[2].split(":")[0];
                        String value = getValue(AckMessageArgs[2]);
                        Log.i(TAG, "Key and Value in Query Ack :" + key + "#" + value);
                        myCursor.addRow(new String[] { key, value });

                        Log.i(TAG, "Query Method inside else, sending message to successor :" + successor.toString()
                                + "#" + queryMessage);
                    }
                } catch (NoSuchAlgorithmException e) {
                    Log.e(TAG, "Insert: Else Block / No Such Algorithm Exception " + e);
                }

            }
            return myCursor;

        } catch (FileNotFoundException e) {
            Log.e(TAG, "Query / FileNotFoundException : " + e);
        } catch (IOException e) {
            Log.e(TAG, "Query / IO Exception : " + e);
            e.printStackTrace();
        }

        return null;
    }



    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public boolean onCreate() {

        // TODO Auto-generated method stub
        String currentNode = getPort(); // returns 111XX
        String nodeAvdNumber = getAvdNumber(currentNode); // returns 555X
        ServerSocket serverSocket = null;

        try {

            new NodeJoins().invoke();
            setSuccNPred();
            serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);



        } catch (Exception e) {
            Log.e(TAG, "onCreate / Exception " + e);
        }

        ClientTask clientTask = new ClientTask();
        clientTask.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,"HI");

        return false;
    }




    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            while (true) {
                try {
                    Socket serverSock = serverSocket.accept();
                    Log.i(TAG, "ServerSocket : " + serverSock.isClosed() + "#isConn" + serverSock.isConnected() + "#"
                            + serverSock.toString());
                    InputStreamReader inputStreamReader = new InputStreamReader(serverSock.getInputStream());
                    Log.i(TAG, "Post InputStreamReader");
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String message = bufferedReader.readLine();
                    Log.i(TAG, serverSock.toString());
                    Log.i(TAG, "received message which is " + message);
                    if (message != null) {

                        if (message.trim().startsWith(insert)) {
                            Log.i(TAG, "Recieving insert Message in Server:" + message);
                            String[] keyValuePairs = message.split("#");
                            Log.i(TAG, "Key:" + keyValuePairs[1]);
                            Log.i(TAG, "Value:" + keyValuePairs[2]);
                            ContentValues cv = new ContentValues();
                            String key = keyValuePairs[1];
                            String value = keyValuePairs[2];
                            cv.put("key", key);
                            cv.put("value", value);
                            insert(providerUri, cv);
                        }

                        if (message.trim().startsWith(query)) {
                            Log.i(TAG, "Recieved Query Message :" + message);
                            String[] queryMessageinServer = message.split("#");
                            String key = queryMessageinServer[3];
                            String sourcePort = queryMessageinServer[4];
                            Log.i(TAG, "Recieved Query Key selection :" + key);
                            Log.i(TAG, "Recieved Query Key selection from " + sourcePort + " Port");
                            if (queue.contains(key)) {
                                Log.i(TAG,"Key " + key +" found in this AVD:" + "CurrentPort" + getPort());
                                String value = hMap.get(key);
                                String Message = "FOUND#" + key + "#" + value + "#" + sourcePort;
                                Log.i(TAG,"Key " + key +" Value " + value);
                                PrintWriter printWriter = new PrintWriter(serverSock.getOutputStream(),true);
                                printWriter.println(Message);
                                printWriter.flush();
                                // ClientTask clientTask = new ClientTask();
                                // clientTask.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,Message,String.valueOf(Integer.parseInt(sourcePort)));

                            } else {
                                Log.i(TAG, "Server Query / Else Block");
                                Socket succSocket = getSocket(String.valueOf(Integer.parseInt(successor) * 2));
                                PrintWriter printWriter = new PrintWriter(succSocket.getOutputStream(), true);
                                printWriter.println(message);
                                Log.i(TAG, "Else - sending to successor:" + message + "to" + successor);
                                printWriter.flush();

                                InputStreamReader inputStreamReader1 = new InputStreamReader(
                                        succSocket.getInputStream());
                                BufferedReader bufferedReader1 = new BufferedReader(inputStreamReader1);
                                String AckMessage = bufferedReader1.readLine();

                                PrintWriter printWriter1 = new PrintWriter(serverSock.getOutputStream(), true);
                                printWriter1.println(AckMessage);
                                printWriter1.flush();

                            }
                        }

                        if (message.trim().startsWith("Delete")) {
                            if (message.equalsIgnoreCase("DeleteALL")) {
                                Log.i(TAG, "DeleteAll Message in server :" + message);
                                hMap.clear();
                            }

                        }

                        if(message.startsWith("REPLI")){
                            Log.i(TAG,"Repli Message rcvd in server" + message);
                            String[] repli_message_string = message.split("#");
                            String key = repli_message_string[1];
                            String value = repli_message_string[2];
                            if(hMap.containsKey(key)){
                                if(getTimeStamp(value).compareTo(hMap.get(key))>0){
                                    hMap.put(key,value);
                                }
                            }
                            hMap.put(key,value);
                            Log.i(TAG,"Adding to Replicated Map : " + replicatedHMap.toString());
                        }

                        if(message.startsWith("GIVEMYDATA")){
                            Log.i(TAG,"HMap in givedata :" + hMap.toString());
                            Log.i(TAG, "entered give my data block ");
                            String ACK = "GIVEMYDATA_ACK" + "#";
                            PrintWriter printWriter0 = new PrintWriter(serverSock.getOutputStream(), true);
                            Iterator<String> iter = hMap.keySet().iterator();
                            while (iter.hasNext()) {
                                String key = iter.next();
                                String value = hMap.get(key);
                                Log.i(TAG,"value in givemydata:" +value);
                                ACK = ACK + key + "@" + value + "-";
                            }

                            printWriter0.println(ACK);
                            Log.i(TAG,"sending ack in server : " + ACK);
                            printWriter0.flush();
                            printWriter0.close();
                        }



                        if (message.trim().startsWith("GDUMP")) {

                            Log.i(TAG, "received GDUMP in server for message " + message);
                            String[] args = message.split("#");
                            String sender = args[1];
                            if (sender.equalsIgnoreCase(successor)) {
                                Log.i(TAG, "sender.equalsIgnoreCase(successor) " + sender.equalsIgnoreCase(successor));
                                PrintWriter printWriter = new PrintWriter(serverSock.getOutputStream(), true);
                                JSONObject json = new JSONObject();
                                Iterator<String> iter = hMap.keySet().iterator();
                                while (iter.hasNext()) {
                                    String key = iter.next();
                                    String value = hMap.get(key);
                                    try {
                                        json.put(key, value);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                                printWriter.println(json.toString());
                                printWriter.flush();
                            } else {
                                Log.i(TAG, "Not sender.equalsIgnoreCase(successor) "
                                        + sender.equalsIgnoreCase(successor) + " successor is " + successor);
                                Socket successorSocket = getSocket(String.valueOf(Integer.parseInt(successor) * 2));
                                PrintWriter printWriter0 = new PrintWriter(successorSocket.getOutputStream(), true);
                                printWriter0.println(message);
                                printWriter0.flush();
                                InputStreamReader inputStreamReader1 = new InputStreamReader(
                                        successorSocket.getInputStream());
                                BufferedReader bufferedReader1 = new BufferedReader(inputStreamReader1);
                                String AckMessageGDUMP = bufferedReader1.readLine();
                                Log.i(TAG, " AckMessageGDUMP in server " + AckMessageGDUMP);

                                JSONObject json = new JSONObject(AckMessageGDUMP);

                                PrintWriter printWriter = new PrintWriter(serverSock.getOutputStream(), true);
                                Iterator<String> iter = hMap.keySet().iterator();
                                while (iter.hasNext()) {
                                    String key = iter.next();
                                    String value = hMap.get(key);
                                    try {
                                        json.put(key, value);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                                printWriter.println(json.toString());
                                Log.i(TAG, " json.toString() in server " + json.toString());
                                printWriter.flush();
                            }
                        }



                    }

                    Log.i(TAG, " POST if predecessorPort is " + predecessor);
                    Log.i(TAG, " POST if sucessorPort is " + successor);
                    // serverSock.close();
                    // serverSock.close();

                } catch (IOException e) {
                    Log.e(TAG, "ServerTask / IO Exception  : " + e);
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {

            try {
                /*Socket socket = new Socket(InetAddress.getByAddress(new byte[] { 10, 0, 2, 2 }),
                        Integer.parseInt("5554") * 2);*/
                String message = msgs[0];
                Log.i(TAG, "ClientTask / General Message : " + message + "#Port#" + getPort());


                /*if (message.startsWith(insert)) {

                    String successorNode = String.valueOf(Integer.parseInt(msgs[1]) * 2);
                    Socket successorSock = getSocket(successorNode);
                    PrintWriter printWriter1 = new PrintWriter(successorSock.getOutputStream(), true);
                    printWriter1.println(message);
                    printWriter1.flush();
                    successorSock.close();
                    Log.i(TAG, "Insert Message recieved in ClientTask : " + message);
                }*/

                if (message.startsWith(query)) {
                    String[] queryArgs = message.split("#");
                    String successorNode = String.valueOf(Integer.parseInt(successor) * 2);
                    Socket successorSock = getSocket(successorNode);
                    Log.i(TAG, "Query message received in clientTask" + message);
                    PrintWriter printWriter = new PrintWriter(successorSock.getOutputStream(), true);
                    printWriter.println(message);
                    printWriter.flush();
                }

                if(message.startsWith("HI")){
                    Log.i(TAG,"Hi in client");
                    String Allkv = "";
                    for(Node node:nodeArrayList){
                        try{
                            if(!node.getPortNumber().equals(getAvdNumber(getPort()))){
                                Log.i(TAG,"Sending to " + String.valueOf(Integer.parseInt(node.getPortNumber())));
                                Socket socket = getSocket(String.valueOf(Integer.parseInt(node.getPortNumber())*2));
                                PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);
                                printWriter.println("GIVEMYDATA");
                                printWriter.flush();

                                InputStreamReader inputStreamReader = new InputStreamReader(socket.getInputStream());
                                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                                String message_ack = bufferedReader.readLine();
                                Log.i(TAG,"recv ack in client:" + message_ack);

                                if(message_ack.startsWith("GIVEMYDATA_ACK")){
                                    String[] key_value_pair_str = message_ack.split("#");
                                    if(key_value_pair_str.length>1){
                                        Allkv = Allkv + key_value_pair_str[1];
                                    }

                                }


                            }
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                    Log.i(TAG,"ALL: " + Allkv);
                    if(Allkv!=null){
                        String[] key_value_pairs = Allkv.split("-");
                        if (key_value_pairs.length>1) {
                            for(String kv:key_value_pairs){
                                Log.i(TAG,"Printing kv string: " + kv);
                                String[] kvpairs = kv.split("@");
                                String key = kvpairs[0];
                                String value = kvpairs[1];
                                Log.i(TAG,"key value pairs done splitting # key :" + key + "# Value :" + value);
                                String[] nodes = getOwners(key).split("#");
                                for(String node:nodes){
                                    if(node.equals(getAvdNumber(getPort()))){
                                        if(hMap.containsKey(key)){
                                            if(getTimeStamp(value).compareTo(getTimeStamp(hMap.get(key)))>0){
                                                hMap.put(key,value);
                                            }
                                        }
                                        else{
                                            hMap.put(key,value);
                                        }
                                    }
                                }
                            }
                        }
                    }

                }

                check = true;


                Log.i(TAG, "My Predecessor" + predecessor);
                Log.i(TAG, "My Successor" + successor);

            } catch (IOException e) {
                Log.e(TAG, "ClientTask / IO Exception : " + e);
                e.printStackTrace();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public class Node {
        public String PortNumber;
        public String PortNumberHash;
        public Node predecessor;
        public Node successor;

        public Node(String currentPortNumber, String currentPortNumberHash, Node predecessorPort, Node successorNode) {
            this.PortNumber = currentPortNumber;
            this.PortNumberHash = currentPortNumberHash;
            this.predecessor = predecessor;
            this.successor = successor;
        }

        public String getPortNumber() {
            return PortNumber;
        }

        public Node setPortNumber(String PortNumber) {
            this.PortNumber = PortNumber;
            return this;
        }

        public String getPortNumberHash() {
            return PortNumberHash;
        }

        public Node setPortNumberHash(String PortNumberHash) {
            this.PortNumberHash = PortNumberHash;
            return this;
        }

        public Node getPredecessor() {
            return predecessor;
        }

        public Node setPredecessor(Node predecessor) {
            this.predecessor = predecessor;
            return this;
        }

        public Node getSuccessor() {
            return successor;
        }

        public Node setSuccessor(Node successor) {
            this.successor = successor;
            return this;
        }
    }

    private class NodeJoins {
        public void invoke() {
            Node node_5562 = new Node(Declarations.PORT_5562,PORT_5562_HASH,null,null);
            Node node_5556 = new Node(Declarations.PORT_5556,PORT_5556_HASH,null,null);
            Node node_5554 = new Node(Declarations.PORT_5554,PORT_5554_HASH,null,null);
            Node node_5558 = new Node(Declarations.PORT_5558,PORT_5558_HASH,null,null);
            Node node_5560 = new Node(Declarations.PORT_5560,PORT_5560_HASH,null,null);

            /* PA3 Reference */
            /* ORDER -> 5562,5556,5554,5558,5560 */
            /* 4,1,0,2,3 */
            setNeighbours(node_5562, node_5556, node_5554, node_5558, node_5560);

            addNodesToList(node_5562, node_5556, node_5554, node_5558, node_5560);
        }
    }

    private void setNeighbours(Node node_5562, Node node_5556, Node node_5554, Node node_5558, Node node_5560) {
        node_5554.setPredecessor(node_5556);
        node_5554.setSuccessor(node_5558);

        node_5556.setPredecessor(node_5562);
        node_5556.setSuccessor(node_5554);

        node_5558.setPredecessor(node_5554);
        node_5558.setSuccessor(node_5560);

        node_5560.setPredecessor(node_5558);
        node_5560.setSuccessor(node_5562);

        node_5562.setPredecessor(node_5560);
        node_5562.setSuccessor(node_5556);
    }

    private void addNodesToList(Node node_5562, Node node_5556, Node node_5554, Node node_5558, Node node_5560) {
        nodeArrayList.add(node_5554);
        nodeArrayList.add(node_5556);
        nodeArrayList.add(node_5558);
        nodeArrayList.add(node_5560);
        nodeArrayList.add(node_5562);
    }

    private void setSuccNPred() {
        if(getAvdNumber(getPort()).equals("5554")){
            successor = "5558";
            predecessor = "5556";
        }
        else if(getAvdNumber(getPort()).equals("5556")){
            predecessor = "5562";
            successor = "5554";
        }
        else if(getAvdNumber(getPort()).equals("5558")){
            predecessor = "5554";
            successor = "5560";
        }
        else if(getAvdNumber(getPort()).equals("5560")){
            predecessor = "5558";
            successor = "5562";
        }
        else if(getAvdNumber(getPort()).equals("5562")){
            predecessor = "5560";
            successor = "5556";
        }
    }


    // Generate Hash for a key.
    public String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }


    // To Insert <Key, Value>
    // where Key is the Filename and Value is the Content of the File.
    /* Method used to Insert */
    public void keyIn(String key, String value) {
        try {
            FileOutputStream fileOutputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
            fileOutputStream.write(value.getBytes());
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "File Not Found Exception Raised : " + e);
        } catch (Exception e) {
            Log.e(TAG, "Unknown Exception Caught : " + e);
        }
    }

    /* Method used for Query */
    public String keyOut(String key) {
        String message = null;
        try {
            Context context = getContext();
            FileInputStream fileInputStream = context.openFileInput(key);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            message = bufferedReader.readLine();
            bufferedReader.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "File not found exception : " + e);
        } catch (IOException e) {
            Log.e(TAG, "IOException :" + e);
        } catch (Exception e) {
            Log.e(TAG, "Exception :" + e);
        }
        return message;
    }

    // Returns avd number :: 5554
    public String getAvdNumber(String node) {
        String port = String.valueOf(Integer.parseInt(node) / 2);
        return port;
    }

    // Returns port number :: 11108
    private String getPort() {
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        // Log.i(TAG, "getPort/Telephone Manager : " + tel);
        // Log.i(TAG, "getPort/Line1 Number : " + tel.getLine1Number());
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        // Log.i(TAG, "getPort/Port Str : " + portStr);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        // Log.i(TAG, "getPort/My Port :" + myPort);
        return myPort;
    }

    // Create socket using the passed port.
    private Socket getSocket(String port) throws IOException {
        return new Socket(InetAddress.getByAddress(new byte[] { 10, 0, 2, 2 }), Integer.parseInt(port));
    }

    private String getValue(String value){
        String[] value_string = value.split(":");
        value = value_string[0];
        return value;
    }

    private String getTimeStamp(String value){
        String[] value_string = value.split(":");
        String timeStamp = value_string[1];
        return timeStamp;
    }

    public String getOwners(String key) throws NoSuchAlgorithmException {
        String hashKey = genHash(key);
        String owners =null;
        for(Node n:nodeArrayList){

            if((hashKey.compareTo(genHash(n.getPredecessor().getPortNumber())) >0 && hashKey.compareTo(genHash(n.getPortNumber())) < 0)||
                    (genHash(n.getPredecessor().getPortNumber()).compareTo(genHash(n.getPortNumber()))>0 &&
                            (hashKey.compareTo(genHash(n.getPredecessor().getPortNumber()))>0 || hashKey.compareTo(genHash(n.getPortNumber()))<0))){
                owners =n.getPortNumber()+"#"+n.getSuccessor().getPortNumber()+"#"+n.getSuccessor().getSuccessor().getPortNumber();
                return owners;
            }
        }
        return owners;
    }

    public boolean checkCondition(String key) {
        boolean check = false;
        try {
            Log.i(TAG,"Pred" + predecessor + "# Succe : "  + successor );
            if (loneNodeCondition() || (genHash(getAvdNumber(getPort())).compareTo(genHash(predecessor)) < 0
                    && (genHash(key).compareTo(genHash(predecessor)) > 0
                    || genHash(key).compareTo(genHash(getAvdNumber(getPort()))) < 0))) {
                Log.i(TAG, "key :" + key);
                Log.i(TAG, "Before setting check to true #" + check);
                check = true;
                Log.i(TAG, "After setting check to true #" + check);
            }

            else if (loneNodeCondition() || (genHash(getAvdNumber(getPort())).compareTo(genHash(predecessor)) > 0
                    && (genHash(key).compareTo(genHash(getAvdNumber(getPort()))) < 0
                    && genHash(key).compareTo(genHash(predecessor)) > 0))) {
                Log.i(TAG, "key :" + key);
                Log.i(TAG, "2 Before setting check to true #" + check);
                check = true;
                Log.i(TAG, "2 After setting check to true #" + check);

            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return check;
    }

    private void sendMessage(String node, String message) throws IOException {
        Socket successorSocket = getSocket(String.valueOf(Integer.parseInt(node) * 2));

        PrintWriter printWriter0 = new PrintWriter(successorSocket.getOutputStream(), true);
        printWriter0.println(message);
        printWriter0.flush();
    }

    private String rcvMessage(String node) throws IOException {
        Socket successorSocket = getSocket(String.valueOf(Integer.parseInt(node) * 2));

        InputStreamReader inputStreamReader = new InputStreamReader(successorSocket.getInputStream());
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String msg = bufferedReader.readLine();
        return msg;
    }

    private boolean loneNodeCondition() {
        return successor.equals("") || successor.equals(null);
    }

    private boolean inAny(String[] ports1) {
        return ports1[0].equals(getAvdNumber(getPort())) || ports1[1].equals(getAvdNumber(getPort())) || ports1[2].equals(getAvdNumber(getPort()));
    }

}